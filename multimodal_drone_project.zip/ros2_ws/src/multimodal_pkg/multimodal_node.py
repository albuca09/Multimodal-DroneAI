
# Placeholder – copiar código completo do guia
